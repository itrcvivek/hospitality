import React from 'react'

function Service() {
  return (
    <>
        Service Page
    </>
  )
}

export default Service
